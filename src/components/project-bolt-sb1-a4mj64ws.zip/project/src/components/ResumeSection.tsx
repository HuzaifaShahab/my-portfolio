import React, { useState } from 'react';

type Tab = 'experience' | 'education' | 'skills' | 'about';

interface ExperienceItem {
  period: string;
  title: string;
  company: string;
}

interface EducationItem {
  year: string;
  title: string;
  institution: string;
}

const experienceData: ExperienceItem[] = [
  {
    period: '2022 - Present',
    title: 'Full Stack Developer',
    company: 'Tech Solutions Inc.',
  },
  {
    period: 'Summer 2021',
    title: 'Front-End Developer Intern',
    company: 'Web Design Studio',
  },
  {
    period: '2020 - 2021',
    title: 'Freelance Web Developer',
    company: 'E-commerce Startup',
  },
  {
    period: '2019 - 2020',
    title: 'Teaching Assistant',
    company: 'Tech Academy',
  },
];

const educationData: EducationItem[] = [
  {
    year: '2023',
    title: 'Full Stack Web Development Bootcamp',
    institution: 'Online Course Platform',
  },
  {
    year: '2022',
    title: 'Front-end Track',
    institution: 'Codecademy',
  },
  {
    year: '2020 - 2021',
    title: 'Programming Course',
    institution: 'Online Course',
  },
  {
    year: '2019',
    title: 'Certified Web Developer',
    institution: 'Tech Institute',
  },
];

const aboutData = {
  name: 'Huzaifa Shahab',
  phone: '(+40) 321 654 876',
  experience: '5+ Years',
  skype: 'huzaifa.01',
  nationality: 'Pakistani',
  email: 'huzaifa.01@gmail.com',
  freelance: 'Available',
  languages: 'English, Urdu',
};

const ResumeSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('experience');

  const getTabStyle = (tab: Tab) => {
    return `w-full py-3 px-4 text-left transition-all duration-300 ${
      activeTab === tab 
        ? 'bg-green-400 text-black' 
        : 'bg-[#1e1e1e] text-gray-400 hover:bg-[#252525]'
    }`;
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'experience':
        return (
          <div>
            <h2 className="text-4xl font-bold mb-4 font-mono">My experience</h2>
            <p className="text-gray-400 mb-8">
              Professional journey and work experience in software development.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {experienceData.map((item, index) => (
                <div key={index} className="bg-[#1e1e1e] p-6 rounded-lg">
                  <div className="text-green-400 text-sm mb-2 font-mono">{item.period}</div>
                  <h3 className="text-white text-xl mb-2 font-mono">{item.title}</h3>
                  <div className="text-gray-400 text-sm flex items-center">
                    <span className="w-2 h-2 bg-green-400 rounded-full mr-2"></span>
                    {item.company}
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case 'education':
        return (
          <div>
            <h2 className="text-4xl font-bold mb-4 font-mono">My education</h2>
            <p className="text-gray-400 mb-8">
              Educational background and professional certifications.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {educationData.map((item, index) => (
                <div key={index} className="bg-[#1e1e1e] p-6 rounded-lg">
                  <div className="text-green-400 text-sm mb-2 font-mono">{item.year}</div>
                  <h3 className="text-white text-xl mb-2 font-mono">{item.title}</h3>
                  <div className="text-gray-400 text-sm flex items-center">
                    <span className="w-2 h-2 bg-green-400 rounded-full mr-2"></span>
                    {item.institution}
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case 'about':
        return (
          <div>
            <h2 className="text-4xl font-bold mb-4 font-mono">About me</h2>
            <p className="text-gray-400 mb-8">
              Personal information and contact details.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-y-6 gap-x-12">
              {Object.entries(aboutData).map(([key, value]) => (
                <div key={key} className="flex justify-between items-center">
                  <span className="text-gray-400 capitalize font-mono">{key}</span>
                  <span className="text-white font-mono">{value}</span>
                </div>
              ))}
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <section id="resume" className="py-32 bg-[#121212]">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
          {/* Left Column */}
          <div>
            <h2 className="text-4xl font-bold mb-4 font-mono">Why hire me?</h2>
            <p className="text-gray-400 mb-8">
              I bring a unique blend of technical expertise and creative problem-solving to every project.
            </p>
            
            <div className="space-y-2">
              <button 
                className={getTabStyle('experience')}
                onClick={() => setActiveTab('experience')}
              >
                Experience
              </button>
              <button 
                className={getTabStyle('education')}
                onClick={() => setActiveTab('education')}
              >
                Education
              </button>
              <button 
                className={getTabStyle('skills')}
                onClick={() => setActiveTab('skills')}
              >
                Skills
              </button>
              <button 
                className={getTabStyle('about')}
                onClick={() => setActiveTab('about')}
              >
                About me
              </button>
            </div>
          </div>

          {/* Right Column - Dynamic Content */}
          <div className="lg:col-span-2">
            {renderContent()}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ResumeSection;