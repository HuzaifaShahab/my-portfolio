import React from 'react';
import { Heart } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="py-8 bg-[#121212] text-center text-gray-400 lg:pl-64">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="mb-4 md:mb-0">
            © {currentYear} Huzaifa Shahab. All rights reserved.
          </div>
          <div className="flex items-center">
            Made with <Heart className="w-4 h-4 text-green-500 mx-1" /> by Huzaifa Shahab
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;