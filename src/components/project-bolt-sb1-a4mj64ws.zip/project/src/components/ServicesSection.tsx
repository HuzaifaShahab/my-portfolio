import React from 'react';
import ServiceCard from './ServiceCard';
import { SERVICE_ITEMS } from '../constants';

const ServicesSection: React.FC = () => {
  return (
    <section id="services" className="py-24 bg-[#121212] lg:pl-64">
      <div className="container mx-auto px-6">
        <div className="mb-16 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">My Services</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            I offer a range of services to help businesses and individuals build their digital presence.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {SERVICE_ITEMS.map((service) => (
            <ServiceCard key={service.id} service={service} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;