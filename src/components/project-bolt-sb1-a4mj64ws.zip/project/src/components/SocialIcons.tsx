import React from 'react';
import { Linkedin, MessageSquare, ExternalLink } from 'lucide-react';

const SocialIcons: React.FC = () => {
  return (
    <div className="flex space-x-6">
      <a
        href="#"
        className="w-12 h-12 rounded-full border-2 border-gray-700 flex items-center justify-center text-gray-400 hover:border-green-400 hover:text-green-400 transition-all duration-300"
        aria-label="LinkedIn"
      >
        <Linkedin className="w-5 h-5" />
      </a>
      <a
        href="#"
        className="w-12 h-12 rounded-full border-2 border-gray-700 flex items-center justify-center text-gray-400 hover:border-green-400 hover:text-green-400 transition-all duration-300"
        aria-label="Fiverr"
      >
        <ExternalLink className="w-5 h-5" />
      </a>
      <a
        href="#"
        className="w-12 h-12 rounded-full border-2 border-gray-700 flex items-center justify-center text-gray-400 hover:border-green-400 hover:text-green-400 transition-all duration-300"
        aria-label="Upwork"
      >
        <ExternalLink className="w-5 h-5" />
      </a>
      <a
        href="#"
        className="w-12 h-12 rounded-full border-2 border-gray-700 flex items-center justify-center text-gray-400 hover:border-green-400 hover:text-green-400 transition-all duration-300"
        aria-label="Reddit"
      >
        <MessageSquare className="w-5 h-5" />
      </a>
    </div>
  );
};

export default SocialIcons;