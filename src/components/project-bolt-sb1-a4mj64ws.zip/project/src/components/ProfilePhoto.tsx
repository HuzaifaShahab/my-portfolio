import React from 'react';

const ProfilePhoto: React.FC = () => {
  return (
    <div className="relative w-[320px] h-[320px] md:w-[480px] md:h-[480px] mx-auto">
      <div className="absolute inset-0 dot-border"></div>
      <div className="absolute inset-[15%] bg-gray-900 rounded-full flex items-center justify-center">
        <div className="text-6xl font-bold text-white">HS</div>
      </div>
    </div>
  );
};

export default ProfilePhoto;