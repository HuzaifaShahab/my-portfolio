import React from 'react';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import CounterSection from './components/CounterSection';
import ResumeSection from './components/ResumeSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';

function App() {
  return (
    <div className="bg-[#121212] text-white min-h-screen">
      <Navbar />
      <main>
        <HeroSection />
        <CounterSection />
        <ResumeSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}

export default App;